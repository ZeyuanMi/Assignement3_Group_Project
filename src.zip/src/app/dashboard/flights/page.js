"use client";

import { useEffect, useState }
    from "react";

export default function TicketsPage() {

    const [tickets, setTickets]
        = useState([]);

    useEffect(() => {

        loadTickets();

    }, []);

    async function loadTickets() {

        const user =
            JSON.parse(
                sessionStorage.getItem("user")
            );

        const response = await fetch(

            `/api/bookings?userId=${user.id}`

        );

        const data =
            await response.json();

        setTickets(data);

    }

    return (

        <div
            style={{
                padding: "40px",
                fontFamily: "monospace",
            }}
        >

            <h1>
                MY TICKETS
            </h1>

            {

                tickets.map((ticket) => (

                    <div
                        key={ticket.id}
                        style={{
                            border: "2px solid black",
                            padding: "20px",
                            marginBottom: "20px",
                            backgroundColor: "white",
                        }}
                    >

                        <p>
                            Booking ID:
                            {" "}
                            {ticket.id}
                        </p>

                        <p>
                            Flight ID:
                            {" "}
                            {ticket.flight_id}
                        </p>

                    </div>

                ))

            }

        </div>

    );

}